import java.util.ArrayList; // Importa a classe ArrayList do pacote java.util
import java.util.Scanner; // Importa a classe Scanner do pacote java.util

class Conta { // Declaração da classe Conta
    private String nomeTitular; // Declaração do atributo nomeTitular do tipo String
    private int numero; // Declaração do atributo numero do tipo int
    private double saldo; // Declaração do atributo saldo do tipo double

    public Conta(String nomeTitular, int numero, double saldo) { // Declaração do construtor Conta com parâmetros
        this.nomeTitular = nomeTitular; // Inicialização do atributo nomeTitular com o valor do parâmetro
        this.numero = numero; // Inicialização do atributo numero com o valor do parâmetro
        this.saldo = saldo; // Inicialização do atributo saldo com o valor do parâmetro
    }

    public int getNumero() { // Método para obter o número da conta
        return numero; // Retorna o número da conta
    }

    public double getSaldo() { // Método para obter o saldo da conta
        return saldo; // Retorna o saldo da conta
    }

    public String getNomeTitular() { // Método para obter o nome do titular da conta
        return nomeTitular; // Retorna o nome do titular da conta
    }

    public void setNomeTitular(String nomeTitular) { // Método para definir o nome do titular da conta
        this.nomeTitular = nomeTitular; // Define o nome do titular da conta com o valor do parâmetro
    }

    public boolean sacar(double valor) { // Método para realizar um saque
        if (valor > saldo) { // Verifica se o valor do saque é maior que o saldo disponível
            System.out.println("Saldo insuficiente."); // Imprime mensagem de saldo insuficiente
            return false; // Retorna false indicando que o saque não foi efetuado
        } else {
            saldo -= valor; // Subtrai o valor do saque do saldo
            System.out.println("Saque efetuado com sucesso. Novo saldo: " + saldo); // Imprime mensagem de saque efetuado com sucesso
            return true; // Retorna true indicando que o saque foi efetuado
        }
    }

    public void depositar(double valor) { // Método para realizar um depósito
        saldo += valor; // Adiciona o valor do depósito ao saldo
        System.out.println("Depósito efetuado com sucesso. Novo saldo: " + saldo); // Imprime mensagem de depósito efetuado com sucesso
    }
}

public class PBL3 { // Declaração da classe PBL3
    public static void main(String[] args) { // Método principal
        try (Scanner scanner = new Scanner(System.in)) { // Criação de um objeto Scanner para entrada de dados
            ArrayList<Conta> contas = new ArrayList<>(); // Criação de um ArrayList para armazenar as contas
            int opcao; // Declaração da variável opcao

            do { // Início do loop do-while
                System.out.println("Escolha uma opção:"); // Imprime mensagem para escolha de opção
                System.out.println("1 - Criar uma conta"); // Imprime opção para criar uma conta
                System.out.println("2 - Ver o saldo de uma conta"); // Imprime opção para ver o saldo de uma conta
                System.out.println("3 - Sacar"); // Imprime opção para sacar
                System.out.println("4 - Depositar"); // Imprime opção para depositar
                System.out.println("Qualquer outro número para finalizar"); // Imprime opção para finalizar o programa

                opcao = scanner.nextInt(); // Lê a opção escolhida pelo usuário

                switch (opcao) { // Início da estrutura switch-case
                    case 1: // Caso a opção seja 1
                        criarConta(contas); // Chama o método para criar uma conta
                        break; // Sai do switch
                    case 2: // Caso a opção seja 2
                        verSaldo(contas); // Chama o método para ver o saldo de uma conta
                        break; // Sai do switch
                    case 3: // Caso a opção seja 3
                        sacar(contas); // Chama o método para sacar
                        break; // Sai do switch
                    case 4: // Caso a opção seja 4
                        depositar(contas); // Chama o método para depositar
                        break; // Sai do switch
                    default: // Caso a opção não seja 1, 2, 3 ou 4
                        System.out.println("Programa finalizado."); // Imprime mensagem de finalização do programa
                }
            } while (opcao >= 1 && opcao <= 4); // Repete o loop enquanto a opção estiver entre 1 e 4
        }
    }

    private static void criarConta(ArrayList<Conta> contas) { // Método para criar uma nova conta
        try (Scanner scanner = new Scanner(System.in)) { // Criação de um objeto Scanner para entrada de dados
            System.out.println("Digite o nome do titular:"); // Imprime mensagem solicitando o nome do titular
            String nomeTitular = scanner.nextLine(); // Lê o nome do titular digitado pelo usuário
            System.out.println("Digite o saldo inicial:"); // Imprime mensagem solicitando o saldo inicial
            double saldoInicial = scanner.nextDouble(); // Lê o saldo inicial digitado pelo usuário
            int numeroConta = contas.size() + 1; // Define o número da conta como o próximo disponível
            Conta novaConta = new Conta(nomeTitular, numeroConta, saldoInicial); // Cria uma nova conta com os dados fornecidos
            contas.add(novaConta); // Adiciona a nova conta à lista de contas
            System.out.println("Conta criada com sucesso. Número da conta: " + numeroConta); // Imprime mensagem de sucesso na criação da conta
        }
    }

    private static void verSaldo(ArrayList<Conta> contas) { // Método para ver o saldo de uma conta
        try (Scanner scanner = new Scanner(System.in)) { // Criação de um objeto Scanner para entrada de dados
            System.out.println("Digite o número da conta:"); // Imprime mensagem solicitando o número da conta
            int numeroConta = scanner.nextInt(); // Lê o número da conta digitado pelo usuário
            Conta conta = encontrarConta(contas, numeroConta); // Procura a conta com o número fornecido
            if (conta != null) { // Se a conta for encontrada
                System.out.println("Saldo da conta " + numeroConta + ": " + conta.getSaldo()); // Imprime o saldo da conta
            }
        }
    }

    private static void sacar(ArrayList<Conta> contas) { // Método para realizar um saque
        try (Scanner scanner = new Scanner(System.in)) { // Criação de um objeto Scanner para entrada de dados
            System.out.println("Digite o número da conta:"); // Imprime mensagem solicitando o número da conta
            int numeroConta = scanner.nextInt(); // Lê o número da conta digitado pelo usuário
            Conta conta = encontrarConta(contas, numeroConta); // Procura a conta com o número fornecido
            if (conta != null) { // Se a conta for encontrada
                System.out.println("Digite o valor a ser sacado:"); // Imprime mensagem solicitando o valor a ser sacado
                double valor = scanner.nextDouble(); // Lê o valor do saque digitado pelo usuário
                conta.sacar(valor); // Realiza o saque na conta
            }
        }
    }

    private static void depositar(ArrayList<Conta> contas) { // Método para realizar um depósito
        try (Scanner scanner = new Scanner(System.in)) { // Criação de um objeto Scanner para entrada de dados
            System.out.println("Digite o número da conta:"); // Imprime mensagem solicitando o número da conta
            int numeroConta = scanner.nextInt(); // Lê o número da conta digitado pelo usuário
            Conta conta = encontrarConta(contas, numeroConta); // Procura a conta com o número fornecido
            if (conta != null) { // Se a conta for encontrada
                System.out.println("Digite o valor a ser depositado:"); // Imprime mensagem solicitando o valor a ser depositado
                double valor = scanner.nextDouble(); // Lê o valor do depósito digitado pelo usuário
                conta.depositar(valor); // Realiza o depósito na conta
            }
        }
    }

    private static Conta encontrarConta(ArrayList<Conta> contas, int numeroConta) { // Método para encontrar uma conta pelo número
        for (Conta conta : contas) { // Percorre todas as contas na lista de contas
            if (conta != null && conta.getNumero() == numeroConta) { // Verifica se a conta não é nula e tem o número desejado
                return conta; // Retorna a conta encontrada
            }
        }
        System.out.println("Conta não encontrada."); // Imprime mensagem indicando que a conta não foi encontrada
        return null; // Retorna null indicando que a conta não foi encontrada
    }
}
